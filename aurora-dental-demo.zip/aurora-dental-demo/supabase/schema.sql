-- Executar no SQL Editor do Supabase. Nunca expor SERVICE_ROLE_KEY no navegador.
create table if not exists public.leads (id uuid primary key default gen_random_uuid(),name text not null,whatsapp text not null,treatment text,consent_at timestamptz not null,created_at timestamptz not null default now());
alter table public.leads enable row level security;
-- Sem políticas públicas: inserção apenas pelo backend usando service role.
