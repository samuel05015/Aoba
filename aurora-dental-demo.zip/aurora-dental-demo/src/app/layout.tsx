import type { Metadata } from 'next';
import { Manrope, DM_Sans } from 'next/font/google';
import { clinic } from '@/config/clinic';
import './globals.css';
const manrope=Manrope({subsets:['latin'],variable:'--font-manrope',display:'swap'});
const dm=DM_Sans({subsets:['latin'],variable:'--font-dm',display:'swap'});
export const metadata:Metadata={title:`${clinic.name} | Cuidado odontológico`,description:clinic.description,robots:{index:false,follow:false},openGraph:{title:clinic.name,description:clinic.description,type:'website'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body className={`${manrope.variable} ${dm.variable}`}>{children}</body></html>}
